Thanks for downloading rAlert!! 

This file contains instructions on how to edit, create and remove notifications in rAlert


---Editing notifications

- Open folder ssar -> tiles -> any number you want, 1 is top notification and 4 is bottom one
- To change contents of a tile open a file "c.html" and type in anything you want to be displayed
- To change title of a tile open a file "mt.html" and enter any title you want
- To change date open file "dt.html" this doesn't have to be for date, you can type anything you want in here
- Trigger the notification by entering any number into the "num.html" that is not the same as the previous one. This only works for the first tile
- To change the color of the frame of the tile open file "st.html" and type in 100,255,255,0,255 for yellow or 100,0,128,255,255 for blue. You can enter any color you want it just has to be in that format.

---Removing notifications
Currently in version 1.0 of ssar you can not remove notifications, you can remove the text by removing contents of all the files
of that folder but the frame will still be there, so make something up to fill that extra space